// See https://github.com/dialogflow/dialogflow-fulfillment-nodejs
// for Dialogflow fulfillment library docs, samples, and to report issues
'use strict';

const functions = require('firebase-functions');
const { WebhookClient } = require('dialogflow-fulfillment');
const { Card, Suggestion } = require('dialogflow-fulfillment');
// fire base config
const admin = require('firebase-admin');

admin.initializeApp({
  credential: admin.credential.applicationDefault(),
  databaseURL: "ws://storemitra-gtovui.firebaseio.com/"
});

const db = admin.firestore();
process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements

exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });
  console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
  console.log('Dialogflow Request body: ' + JSON.stringify(request.body));


  function welcome(agent) {
    agent.add(`Which Appliance are you Interested?`);
  }

  function fallback(agent) {
    const session = agent.session.split('/').pop();
    let fallback = agent.getContext('fback');
    console.log(fallback);
    if (Boolean(fallback)) {
      let responseText = fallback.parameters.fallback;
      agent.add(responseText);
    }
    return  admin.database().ref("savingAnswerParams").once('value').then((snapshot) => {
      if (snapshot.child(session).exists()) {
        const value = snapshot.child(session).val();
        if (value !== null) {
          console.log("FallBack parameters:"+value);
          let appliance = value.Appliance.toLowerCase();
          agent.setContext({
            name: appliance,
            lifespan: 5
          });
        }
      }
    });
  }

  function checkDimensionNames(key) {
    key = key.toLowerCase();
    if (key.includes("wide") || key.includes("width") || key.endsWith('in.') || key.endsWith('inch') || key.endsWith('inches') || key.endsWith('inch.') || key.search(/\d+\d?.?\d?\d? [Ii]n\.?/) >= 0 )
      return 'Width';
    if (key.includes("deep") || key.includes("depth"))
      return 'Depth';
    if (key.includes("height") || key.includes("high") || key.includes("tall"))
      return 'Height';
  }

  function handleMultipleParams(curParams, multiParam) {
    for (let i in curParams[multiParam]) {
      let key = curParams[multiParam][i];
      console.log(key);
      let dimKey = checkDimensionNames(key);
      if (Boolean(dimKey))
        curParams[dimKey] = curParams[multiParam][i];
      else
        curParams[curParams[multiParam][i]] = curParams[multiParam][i];
      delete curParams[multiParam][i];
    }
    curParams[multiParam] = null;
    delete curParams[multiParam];
    return curParams;
  }

  function getOriginalEntities(entitiy) {
    return entitiy.replace(/[0-9]/g, '');
  }

  let QUESTION = false;
  let numericEntities ;
  let negativeMapping ;

  function handleQnA(agent, curParams, intent) {
    let query = agent.query;
    let context = agent.getContext(intent.toLowerCase());
    let allKeys = Object.keys(context.parameters);
    const session = agent.session.split('/').pop();
    let insideKeys = [];
    let outsideKeys = [];
    let logParams = {};
    let filterList = [];
    let negMapParams = [];
    let isNumber;
    let isQues = query.indexOf('?');
    for (let i of allKeys) {

      if (Array.isArray(context.parameters[i]) && context.parameters[i].length && !i.includes('original')) {
        for (let j in context.parameters[i]) {
          let origText = context.parameters[i + '.original'][j];

          let paramIndex = query.indexOf(origText);
          let key = checkDimensionNames(context.parameters[i][j]) || context.parameters[i][j];

          if (paramIndex < isQues){
            if (Object.keys(negativeMapping).includes(context.parameters[i][j])){
              negMapParams.push(context.parameters[i][j]);
              insideKeys.push('nonNumberFilter');
            }
            else if (i.includes('FilterList') && i.includes('FilterList') >= 0){
              if (Object.keys(numericEntities).includes(context.parameters[i][j])){

                isNumber = context.parameters[i][j];
                console.log(" isnumber "+ context.parameters[i][j]);
                insideKeys.push(isNumber );
              }
              else{
                insideKeys.push('nonNumberFilter');
              }
            }
            else
              insideKeys.push(key);
          }
          else
            outsideKeys.push(key);
        }
      }
      if (context.parameters[i] !== '' && i.includes('original') &&  !(Array.isArray(context.parameters[i]))) {
        var paramIndex = query.indexOf(context.parameters[i]);

        if (paramIndex < isQues) {

          insideKeys.push(i);
        } else
          outsideKeys.push(i);
      }
    }

    logParams = {
      insideKeys, outsideKeys
    };
    if (insideKeys.length && outsideKeys.length) {
      if (Boolean(curParams.Yes)){
        // retain params in question  eg: Do you entertain groups ? Yes <params here will remain unaltered>
        if(negMapParams.length > 0)
          for (let param of negMapParams) {
            if(Boolean(curParams[param]))
              delete curParams[param];
            if(Boolean(negativeMapping[param][curParams.Yes]))
              curParams =  Object.assign(curParams, negativeMapping[param][curParams.Yes]);
          }
        delete curParams.Yes;
      }
      else if (Boolean(curParams.No)) {
        // delete params in question retain params in answers eg: Do you entertain groups ? No <params here will remain unaltered>

        let Negative = {};
        if(negMapParams.length > 0)
          for (let param of negMapParams) {
            if(Boolean(curParams[param]))
              delete curParams[param];
            curParams =  Object.assign(curParams, negativeMapping[param][curParams.No]);
          }
        for (let i of insideKeys) {
          if(i !== 'nonNumberFilter'){
            Negative[i.split('.')[0]] = curParams[i.split('.')[0]];
            curParams[i.split('.')[0]] = ' ';
          }
        }
        delete curParams.No;
        admin.database().ref('saveQuestionContext').child(session).child('Negative').update(Negative);
      } else if (!(Boolean(curParams.No) || Boolean(curParams.Yes))) {
        // eg: Do you entertain groups ? Black
        //to do : ignore inside keys(delete .original)
        for (let i of insideKeys){
          if(i === isNumber && Boolean(curParams.Number)) {
            curParams[isNumber] = curParams.Number+numericEntities[i];
            delete curParams.Number;

          }
          else if(i !== 'nonNumberFilter')
            delete curParams[i.split('.')[0]];
        }
      }
    }

    //this is pause
    if (insideKeys.length && !outsideKeys.length) {
      let awaitParams = {};

      for (let i of insideKeys) {

        if(i !== 'nonNumberFilter' && i !== isNumber) {
          let key = i.split('.')[0];
          awaitParams[key] = curParams[i.split('.')[0]];

          delete curParams[i.split('.')[0]];
        }
      }

      if(negMapParams.length > 0){
        agent.setContext({
          name: 'awaitnegmap',
          lifespan: 1,
          parameters: {
            'negMapParams' : negMapParams
          }
        });
      }
      agent.setContext({
        name: 'awaitans',
        lifespan: 1,
        parameters: {
          awaitParams
        }
      });
      if(Boolean(isNumber)){
        agent.setContext({
          name: 'awaitnum',
          lifespan: 1,
          parameters: {
            'numericParameter' : isNumber
          }
        });
      }
      // console.log("Context " + agent.getContext("awaitans"));
      logParams = Object.assign(logParams, awaitParams);
      QUESTION = true;
    }
    let time = new Date().getTime();
    console.log('log params => ' + JSON.stringify(logParams));
    admin.database().ref('saveQuestionContext').child(session).child(time).set(logParams);
    return curParams;
  }


  function handleReadDB(agent) {
    const session = agent.session.split('/').pop();
    console.log("sessionID =>" + session);
    let intent = agent.intent;
    intent = intent.replace(/get/i, "");
    intent = intent.replace(/details/i, "");
    var params, seq, curParams, paramString;
    curParams = JSON.parse(JSON.stringify(agent.parameters).replace(/\//g,'_'));
    let nextSequence = agent.getContext('nextseq');

    if (Boolean(nextSequence))
      curParams = JSON.parse(JSON.stringify(nextSequence.parameters.curParams));
    for (let i in curParams) {
      if (Array.isArray(curParams[i]) && curParams[i].length === 0) {
        curParams[i] = null;
        delete curParams[i];
      }
      if (Array.isArray(curParams[i]) && curParams[i].length > 0 && i !== 'FilterList') {

        curParams = handleMultipleParams(curParams, i);
      }
      if (curParams[i] === '')
        delete curParams[i];
    }
    if (Object.keys(curParams).length === 0 && curParams.constructor === Object) {
      console.log("Inside fallback" + JSON.stringify(curParams));
      agent.setContext({
        name: intent,
        lifespan: 5
      });
      agent.setFollowupEvent("Fallback");
    } else {
      let query = agent.query;
      let isQues = query.indexOf('?');
      if (isQues > 0)
        curParams = handleQnA(agent, curParams, intent);
      let awaitans = agent.getContext('awaitans');
      // console.log(awaitans);
      if (Boolean(awaitans)) {
        let awaitParams = awaitans.parameters.awaitParams;
        if (Boolean(curParams.Yes)) {
          let awaitnegmap = agent.getContext('awaitnegmap');
          if (Boolean(awaitnegmap)) {
            let negMapParams = awaitnegmap.parameters.negMapParams;
            for (let param of negMapParams) {
              if(Boolean(curParams[param]))
                delete curParams[param];
              if(Boolean(negativeMapping[param][curParams.Yes]))
                curParams =  Object.assign(curParams, negativeMapping[param][curParams.Yes]);
            }
          }
          curParams = Object.assign(curParams, awaitParams);
          // console.log("Inside await ans = " + JSON.stringify(curParams));
        }
        else if(Boolean(curParams.No)) {
          let awaitnegmap = agent.getContext('awaitnegmap');
          if (Boolean(awaitnegmap)) {
            let negMapParams = awaitnegmap.parameters.negMapParams;
            for (let param of negMapParams) {
              if(Boolean(curParams[param]))
                delete curParams[param];
              curParams =  Object.assign(curParams, negativeMapping[param][curParams.No]);
            }
          }
          for(let param in awaitParams)
            if(!Boolean(curParams[param]))
              curParams[param] = ' ';

          admin.database().ref('saveQuestionContext').child(session).child('Negative').update(awaitParams);
        }
      }

      let awaitnum = agent.getContext('awaitnum');
      console.log(awaitnum);
      if (Boolean(awaitnum)) {
        let numericParameter = awaitnum.parameters.numericParameter;
        if (Boolean(curParams.Number)) {
          curParams[numericParameter] = curParams.Number+numericEntities[numericParameter];
          console.log("Inside await ans = " + JSON.stringify(curParams));
        }
      }

      // handle only number
      if (!Boolean(awaitnum) && Boolean(curParams.Number) && Object.keys(curParams).length === 1){
        agent.setContext({
          name: 'fback',
          lifespan: 2,
          parameters: {
            fallback:'Please say units'
          }
        });
        return agent.setFollowupEvent("Fallback");
      }

      if (isQues<=0 && !Boolean(awaitans) && Boolean(curParams.No)) {
        delete curParams.No;
        admin.database().ref('saveQuestionContext').child(session).child('Negative').update(curParams);
        curParams = {};
      }
      //if(Boolean(curParams.Appliance))
      curParams.Appliance = intent;
      // console.log("writing current params =>" + JSON.stringify(curParams));
      // delete FilterList
      curParams.FilterList = null;
      delete curParams.FilterList;
      admin.database().ref('savingAnswerParams').child(session).update(curParams);

      let curParamsValues = Object.values(curParams);
      getParams(session, function(store) {
        let seqParams = [];
        if (store.seqParams) {
          seqParams = store.seqParams.slice();
        }
        seqParams.push(curParamsValues);
        seq = store.seq || 0;
        params = store;
        if (!params.Appliance) {
          params.Appliance = intent;
        }
        if (!Boolean(QUESTION))
          params.seq = parseInt(seq) + 1;
        params.Timestamp = new Date().getTime();
        params.seqParams = seqParams;
        admin.database().ref('savingAnswerParams').child(session).set(params);
        let tmpParams = JSON.parse(JSON.stringify(params));
        //console.log('before tmpParams => '+JSON.stringify(tmpParams)+Object.keys(tmpParams).length);
        tmpParams = removeNonMLParams(tmpParams);
        // console.log('tmpParams => '+JSON.stringify(tmpParams)+Object.keys(tmpParams).length);
        if(Object.keys(tmpParams).length > 1)
          delete tmpParams.Appliance;
        let paramValues = Object.values(tmpParams);
        paramValues = paramValues.filter(entry => entry.trim() != '');
        paramString = paramValues.sort().join(',')  ;
        paramString =  paramString === intent ? 'frequentItem' : paramString;
        paramString = paramString.replace(/\./g,'@');
        paramString = paramString.replace(/\$/g,'~');
        console.log('paramString'+paramString);
      });



      return admin.database().ref("MLData").once('value').then((mlsnapshot) => {
        if(Boolean(paramString)){
          mlsnapshot = mlsnapshot.child(params.Appliance.toLowerCase()).child(paramString).val();
          // console.log('mlsnapshot => '+mlsnapshot);
          if(!Boolean(mlsnapshot))
            return fetchGenaralQualifyingQuestion(agent,params,curParams);

          else
            // agent.add('mlData');
            return fetchMLQualifyingQuestion(agent,params,curParams,mlsnapshot,paramString);
        }
        else
          return fetchGenaralQualifyingQuestion(agent,params,curParams);





      });



    }
  }

  function fetchMLQualifyingQuestion(agent,params,curParams,mlsnapshot,paramString) {
    return admin.database().ref("staticQualifyingQuestions").once('value').then((snapshot) => {
      snapshot = snapshot.child(params.Appliance.toLowerCase());
      snapshot = snapshot.val();
      console.log(snapshot);
      let seqQuestions = filterObject(snapshot,'seq',params.seq);
      console.log(params.seq);
      console.log("Sequence Questions => "+JSON.stringify(seqQuestions) +Object.keys(seqQuestions).length);
      if (Object.keys(seqQuestions).length > 0) {
        agent.setContext({
          name: params.Appliance.toLowerCase(),
          lifespan: 5
        });
        let curSeqParams = Object.keys(mlsnapshot);
        let curSeqValues = Object.values(mlsnapshot);
        let baseParams = curSeqParams.map(getOriginalEntities);

        let questionEntity,questionValues ;

        if (!Boolean(QUESTION)) {
          // i = paramString === 'default' ? Math.round(Math.random() * curSeqParams.length-1) : i;
          for (var i in baseParams){
            i = paramString === 'frequentItem' ? Math.round(Math.random() * curSeqParams.length-1) : i;
            if (!Boolean(params[baseParams[i]])) {
              questionEntity = baseParams[i];
              console.log('questionEntity =>'+questionEntity);
              questionValues = curSeqValues[i].split(',');
              console.log('questionValues =>'+questionValues);
              curSeqValues.splice(i,1);
              let temp = [];
              for (let i of curSeqValues){
                temp = temp.concat(i.split(','));
              }
              curSeqValues = temp;
              break;

            }
          }
          if(!Boolean(questionEntity))
            questionEntity = 'GeneralFeatures';
          if(Boolean(questionValues)){
            let qualifyingQuestionKeys = Object.keys(snapshot);
            let baseQualifyingQuestionKeys = qualifyingQuestionKeys.map(getOriginalEntities);
            let questionIndex = baseQualifyingQuestionKeys.indexOf(questionEntity);
            console.log('questionEntity  '+questionEntity);
            let tempQuestion = snapshot[qualifyingQuestionKeys[questionIndex]];
            console.log('questionValues =>'+questionValues);
            console.log('curSeqValues =>'+curSeqValues);
            if(questionValues[0] === 'Cut Out' || questionValues[0] === 'Island')
              questionValues.splice(0,1);
            // append ml value with qualifying question values
            var finaloptions = questionValues.concat(tempQuestion.options.filter((item) => questionValues.indexOf(item) < 0));
            // apeend remaning ml values to final options
            finaloptions = finaloptions.concat(curSeqValues.filter((item) => finaloptions.indexOf(item) < 0));
            //  console.log('before filter =>'+finaloptions);
            finaloptions =  finaloptions.filter(value => !Object.values(params).includes(value));
            console.log('after filter =>'+finaloptions);
            let finalQuestion = {options:finaloptions,question:tempQuestion.question};
            agent.add(JSON.stringify(finalQuestion).replace("\\", ""));
          }
          else {
            return fetchGenaralQualifyingQuestion(agent,params,curParams);

          }


        }

      }else {
        if (!Boolean(QUESTION))
          agent.setFollowupEvent("search");
      }
    });
  }


  function fetchGenaralQualifyingQuestion(agent,params,curParams){
    return admin.database().ref("staticQualifyingQuestions").once('value').then((snapshot) => {
      snapshot = snapshot.child(params.Appliance.toLowerCase());
      snapshot = snapshot.val();
      let seqQuestions = filterObject(snapshot,'seq',params.seq);
      console.log("Sequence Questions => "+JSON.stringify(seqQuestions) +Object.keys(seqQuestions).length);
      if (Object.keys(seqQuestions).length > 0) {
        agent.setContext({
          name: params.Appliance.toLowerCase(),
          lifespan: 5
        });
        const value = seqQuestions;
        let curSeqParams = Object.keys(value);
        let baseParams = curSeqParams.map(getOriginalEntities);
        var visibleCount = 0;
        var next_sequence = true;
        const paramValues = Object.values(params);
        if (!Boolean(QUESTION)) {
          for (var i in baseParams) {
            if (!Boolean(params[baseParams[i]])) {
              let tempQuestion = value[curSeqParams[i]];
              if (visibleCount === 1) {
                tempQuestion.question = "";
              }

              tempQuestion.options =  tempQuestion.options.filter(existValue => !paramValues.includes(existValue));
              delete tempQuestion.seq;
              // agent.query = tempQuestion.question;
              visibleCount = 1;
              agent.add(JSON.stringify(tempQuestion).replace("\\", ""));
              next_sequence = false;
            }
          }
          if (next_sequence) {
            agent.setContext({
              name: 'nextseq',
              lifespan: 2,
              parameters: {
                curParams
              }
            });
            agent.setFollowupEvent(params.Appliance);
          }
        }
        // }
      } else {
        if (!Boolean(QUESTION))
          agent.setFollowupEvent("search");
      }
    });


  }





  function getParams(sessionId, callback) {
    admin.database().ref("savingAnswerParams").once('value').then((snapshot) => {
      if (snapshot.child(sessionId).exists()) {
        const value = snapshot.child(sessionId).val();
        if (value !== null) {
          callback(value);
          console.log(value);
        }
      } else {
        callback(false);
      }
    });
  }

  const filterObject = (obj, filter, filterValue) =>
  Object.keys(obj).reduce((acc, val) =>
                          (obj[val][filter] !== filterValue ? acc : {...acc,
                                                                     [val]: obj[val]
                                                                    }                                        
                          ), {});

  function getKeyByValue(object, value) {
    return Object.keys(object).find(key => object[key] === value);
  }

  function removeFilters(agent) {
    const sessionId = agent.session.split('/').pop();
    let paramValues = agent.parameters.EventParam.split(',');
    //   console.log("check Remove filters" + paramValues);
    if (paramValues && paramValues.length > 0) {
      getParams(sessionId, function(store) {
        if(store.seqParams.length > 1 && store.seqParams[store.seqParams.length-1].join() !== store.Appliance)
          store.seq = Math.max(store.seq - 1, 0);
        let params = store.seqParams[store.seqParams.length-1];
        //let params = store.seqParams[store.seq];
        console.log ("undo params "+ params + " "+ store.seq + " "+ store.seqParams[store.seq]);

        for (let i of params) {
          let key = getKeyByValue(store, i);
          console.log("key undo "+ key +" " +i);
          if (key && key !== "Appliance")
            delete store[key];
          if(key && ( key === "FamilySize" || key === "Size" || key === "Frequency" || key === "ExtraStorage")){
            if(store.Capacity){
              delete store.Capacity;
            }
          }

        }
        delete store.seqParams[store.seqParams.length-1];
        console.log("remove filter => " + JSON.stringify(store));
        admin.database().ref('savingAnswerParams').child(sessionId).set(store);
      });
      agent.add("Removed filters" );
    }
  }

  function resetSession(agent) {
    const sessionId = agent.session.split('/').pop();
    admin.database().ref('savingAnswerParams').child(sessionId).remove();
    admin.database().ref("saveQuestionContext").child(sessionId).remove();
    agent.setFollowupEvent("Welcome");
  }


  function executeSearchDB(agent) {
    const sessionId = agent.session.split('/').pop();
    console.log(sessionId);

    let modelSearch = agent.getContext('modelsearch');

    if (Boolean(modelSearch)) {
      let model = modelSearch.parameters.model;
      console.log(modelSearch.parameters);
      agent.add(JSON.stringify({model:model}));
    }
    else  return admin.database().ref("savingAnswerParams").once('value').then((snapshot) => {
      if (snapshot.child(sessionId).exists()) {
        let value = snapshot.child(sessionId).val();
        if (value !== null) {
          if (value.Frequency === "Monthly" || value.Frequency === "Weekly") {
            value.ExtraStorage = "Yes";
          }
          let appliance = value.Appliance.toLowerCase();
          console.log('appliance before switch : '+appliance);
          agent.setContext({
            name: appliance,
            lifespan: 5
          });
          switch (appliance) {
            case 'refrigerator':
              return getRefrigeratorMapping(agent, value, sessionId);
            case 'dishwasher':
              console.log("Inside Dishwasher");
              return getDishwasherMapping(agent, value, sessionId);
            case 'microwave':
              return getMicrowaveMapping(agent, value, sessionId);
            case 'walloven':
              return getWallovenMapping(agent, value, sessionId);
            case 'washers':
              return getWasherMapping(agent, value, sessionId);
              //case 'dryers':
              // return getWasherMapping(agent, value, sessionId);
            case 'washeranddryer':
              return getWasherMapping(agent, value, sessionId);
            case 'ranges':
              return getRangesMapping(agent, value, sessionId);

            default:
              value = removeNonFilterParams(value);
              console.log("final Params : " + JSON.stringify(value));
              agent.add(JSON.stringify(value).replace(/_/g,'/'));
              return setNegativeFilters(agent, sessionId);
          }
        }
      }
    });
  }


  function removeNonMLParams(params) {
    const nonFilterParams = ["seq", "seqParams", "Timestamp","ExtraStorage", "No","Yes", "Number"];
    for (let i of nonFilterParams)
      delete params[i];
    return params;
  }

  function removeNonFilterParams(params) {
    const nonFilterParams = ["seq", "seqParams", "Timestamp", "FamilySize", "ExtraStorage", "Frequency", "No", "InstallationInstructions", "Yes","Number"];
    for (let i of nonFilterParams)
      delete params[i];
    return params;
  }

  function setNegativeFilters(agent, sessionId) {
    return admin.database().ref("saveQuestionContext").child(sessionId).once('value').then((csnapshot) => {
      const negativeParams = csnapshot.child('Negative').val();
      if(negativeParams !== null){

        negativeParams.Negative = 'Yes';
        console.log(JSON.stringify(negativeParams));
        agent.add(JSON.stringify(negativeParams));
      }
    });
  }

  function getWasherMapping(agent, value, sessionId) {  
    /* return admin.database().ref("lifeStyleParamsMap").once('value').then((csnapshot) => {
      const lifestyleParams = csnapshot.child(value.Appliance.toLowerCase()).val();
      console.log(lifestyleParams);
      if (lifestyleParams !== null) {
        if (Boolean(value.Capacity) === false && value.Size) {
          var family = lifestyleParams.size[value.Size.toLowerCase()];
          if (family !== null) {
            if (value.ExtraStorage === "Yes") {
              family++;
            }
            const capacity = Math.min(family, lifestyleParams.capacity.length - 1);
            value.Capacity = lifestyleParams.capacity[capacity];
          }
        } else {
          if (Boolean(value.Capacity) === false && (value.ExtraStorage || value.Frequency))
            value.Capacity = lifestyleParams.capacity[lifestyleParams.capacity.length - 2];
        }
        admin.database().ref('savingAnswerParams').child(sessionId).set(value);

      }
    });*/

    return admin.database().ref("lifeStyleParamsMap").once('value').then((csnapshot) => {
      const lifestyleParams = csnapshot.child(value.Appliance.toLowerCase()).val();
      console.log(lifestyleParams);
      if (lifestyleParams !== null) {
        if (Boolean(value.Size) === false && value.Frequency) {
          value.Size = lifestyleParams.frequency[value.Frequency];

        }
        admin.database().ref('savingAnswerParams').child(sessionId).set(value);

      }
      value = removeNonFilterParams(value);
      console.log("final Params : " + JSON.stringify(value));
      agent.add(JSON.stringify(value).replace(/_/g,'/'));
      return setNegativeFilters(agent, sessionId);
    });




  }

  function getWallovenMapping(agent, value, sessionId) {
    return admin.database().ref("lifeStyleParamsMap").once('value').then((csnapshot) => {
      const lifestyleParams = csnapshot.child(value.Appliance.toLowerCase()).val();
      console.log("lifestyle params" + lifestyleParams);
      if (lifestyleParams !== null) {
        console.log("Inside WallOven lifestyle params");
        if (value.ExtraStorage === "Yes" && !Boolean(value.Type)) {
          value.Type = 'Double';
        }
        if (value.ExtraStorage === "No" && !Boolean(value.Type)) {
          value.Type = 'Single';
        }
        if (Boolean(value.Width) === false && value.Size) {
          value.Width = lifestyleParams.size[value.Size.toLowerCase()];
        }
        admin.database().ref('savingAnswerParams').child(sessionId).set(value);
        value = removeNonFilterParams(value);
        console.log("final Params : " + JSON.stringify(value));
        agent.add(JSON.stringify(value).replace(/_/g,'/'));
        return setNegativeFilters(agent, sessionId);
      }
    });
  }

  function getMicrowaveMapping(agent, value, sessionId) {
    //let type = value.Style || "default";
    if (value.ExtraStorage === "Yes" && !Boolean(value.Size)) {
      value.Size = "Large";
    }
    // installationtype = cutout venttype = vent
    if (value.Type === "Built In" && Boolean(value.VentType)) {
      value.Type = "Over-the-Range Microwaves";
    }
    admin.database().ref('savingAnswerParams').child(sessionId).set(value);
    value = removeNonFilterParams(value);
    console.log("final Params : " + JSON.stringify(value));
    agent.add(JSON.stringify(value).replace(/_/g,'/'));
    return setNegativeFilters(agent, sessionId);
  }

  function getRefrigeratorMapping(agent, value, sessionId) {
    let type = value.Style || "default";
    return admin.database().ref("lifeStyleParamsMap").once('value').then((csnapshot) => {
      const lifestyleParams = csnapshot.child(value.Appliance.toLowerCase()).val();
      if (lifestyleParams !== null) {
        if (Boolean(value.Capacity) === false && value.FamilySize) {
          var family = lifestyleParams.familySize[value.FamilySize.toLowerCase()];
          if (family !== null) {
            if (value.ExtraStorage === "Yes") {
              family++;
            }
            const capacity = Math.min(family, 7);
            value.Capacity = lifestyleParams.capacity[type][capacity];
          }
        } else {
          if (Boolean(value.Capacity) === false && (value.ExtraStorage || value.Frequency))
            value.Capacity = lifestyleParams.capacity[type][6];
        }
        admin.database().ref('savingAnswerParams').child(sessionId).set(value);
        value = removeNonFilterParams(value);
        console.log("final Params : " + JSON.stringify(value));
        agent.add(JSON.stringify(value).replace(/_/g,'/'));
        return setNegativeFilters(agent, sessionId);
      }
    });
  }

  function getDishwasherMapping(agent, value, sessionId) {
    return admin.database().ref("lifeStyleParamsMap").once('value').then((csnapshot) => {
      const lifestyleParams = csnapshot.child(value.Appliance.toLowerCase()).val();
      console.log("lifestyle params" + lifestyleParams);
      if (lifestyleParams !== null) {
        console.log("Inside Dishwasher lifestyle params");
        if (Boolean(value.Width) === false && value.FamilySize) {
          var family = lifestyleParams.familySize[value.FamilySize.toLowerCase()];
          console.log("Inside Dishwasher family" + family);
          if (family !== null) {
            if (value.ExtraStorage === "Yes") {
              family++;
            }
            const capacity = Math.min(family, 1);
            value.Size = lifestyleParams.size[capacity];
          }
        } else {
          if (Boolean(value.Width) === false && (value.ExtraStorage || value.Frequency))
            value.Size = lifestyleParams.size[1];
        }
        admin.database().ref('savingAnswerParams').child(sessionId).set(value);
        value = removeNonFilterParams(value);
        console.log("final Params : " + JSON.stringify(value));
        agent.add(JSON.stringify(value).replace(/_/g,'/'));
        return setNegativeFilters(agent, sessionId);
      }
    });
  }


  function getRangesMapping(agent, value, sessionId) {
    return admin.database().ref("lifeStyleParamsMap").once('value').then((csnapshot) => {
      const lifestyleParams = csnapshot.child(value.Appliance.toLowerCase()).val();
      console.log("lifestyle params" + lifestyleParams);
      if (lifestyleParams !== null) {
        console.log("Inside Dishwasher lifestyle params");
        if (Boolean(value.Width) === false && value.FamilySize) {
          var family = lifestyleParams.familySize[value.FamilySize.toLowerCase()];
          console.log("Inside Dishwasher family" + family);
          if (family !== null) {
            if (value.ExtraStorage === "Yes") {
              family++;
            }
            const capacity = Math.min(family, lifestyleParams.size.length - 1);
            value.Size = lifestyleParams.size[capacity];
          }
        } else {
          if (Boolean(value.Width) === false && (value.ExtraStorage || value.Frequency))
            value.Size = lifestyleParams.size[lifestyleParams.size.length - 2];
        }
        admin.database().ref('savingAnswerParams').child(sessionId).set(value);
        value = removeNonFilterParams(value);
        console.log("final Params : " + JSON.stringify(value));
        agent.add(JSON.stringify(value).replace(/_/g,'/'));
        return setNegativeFilters(agent, sessionId);
      }
    });
  }


  function getAppliance(agent) {
    const appliance = agent.parameters.Appliance.toLowerCase();
    const sessionId = agent.session.split('/').pop();
    console.log("session in getappliance" + sessionId + appliance);
    if (Boolean(appliance))
      agent.setContext({
        name: appliance,
        lifespan: 5
      });
    else
      agent.setFollowupEvent("Fallback");
  }

  function handleModel(agent) {
    const sessionId = agent.session.split('/').pop();
    const model = agent.parameters.ModelNumbers;
    agent.setContext({
      name: 'modelsearch',
      lifespan: 1,
      parameters: {
        model:model
      }
    });
    agent.setFollowupEvent('search');
    let time = new Date().getTime();

    admin.database().ref('ModelSearch').child(sessionId).child(time).set(model);
  }

  // Run the proper function handler based on the matched Dialogflow intent name
  let intentMap = new Map();
  intentMap.set('Default Welcome Intent', welcome);
  intentMap.set('Default Fallback Intent', fallback);

  intentMap.set('getRefrigeratorDetails', handleReadDB);
  intentMap.set('getDishwasherDetails', handleReadDB);
  intentMap.set('getMicrowaveDetails', handleReadDB);
  intentMap.set('getWallOvenDetails', handleReadDB);
  intentMap.set('getWashersDetails', handleReadDB);
  intentMap.set('getDryersDetails', handleReadDB);
  intentMap.set('getWasherAndDryerDetails', handleReadDB);
  intentMap.set('getRangesDetails', handleReadDB);

  intentMap.set('UndoParams', removeFilters);
  intentMap.set('ResetSession', resetSession);
  intentMap.set('getAppliance', getAppliance);
  intentMap.set('searchAffirmation', executeSearchDB);
  intentMap.set('getModelNumber' , handleModel);

  return admin.database().ref("lifeStyleParamsMap").once('value').then((csnapshot) => {
    numericEntities = csnapshot.child('numericEntities').val();
    negativeMapping = csnapshot.child('negativeMapping').val();
    agent.handleRequest(intentMap);
  });

});